<?php get_header(); ?>
<div class="grid">
			<?php if ( have_posts() ) : ?>
				<?php while ( have_posts() ) : the_post(); ?>
					<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
						<div class="entry clear">
							<?php the_content(); ?>
							<?php edit_post_link(); ?>
							<?php wp_link_pages(); ?>
						</div><!--. entry-->
					</div><!-- .post-->
				<?php endwhile; /* rewind or continue if all posts have been fetched */ ?>
				<?php else : ?>
			<?php endif; ?>
</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>