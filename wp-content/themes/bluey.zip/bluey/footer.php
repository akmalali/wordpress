</div>
<footer class="grid row">
	<div class="c12 end">
	<ul class='footer'>
		<li><a href="http://www.utdallas.edu" title="University&nbsp;of&nbsp;Texas&nbsp;at&nbsp;Dallas">University of Texas at Dallas</a><span class="hide_small">&nbsp;|&nbsp;</span></li>
		<li><a href="http://www.utdallas.edu/research/" title="Office of Research">Office&nbsp;of&nbsp;Research</a><span class="hide_small">&nbsp;|&nbsp;</span></li>
		<li><a href="http://www.utdallas.edu/links/" title="Required Links">Required&nbsp;Links</a><span class="hide_small">&nbsp;|&nbsp;</span></li>
		<li><a href="http://www.utdallas.edu/research/directory/#applied_research_center" title="Contact Us">Contact&nbsp;Us</a></li>
	</ul>
	</div>
</footer>
</div>
</body>
</html>
